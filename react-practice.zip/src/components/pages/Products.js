/** @format */

import React from "react";

function Products() {
  return <div>This is the Products site</div>;
}

export default Products;
