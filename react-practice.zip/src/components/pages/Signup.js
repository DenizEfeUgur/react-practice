/** @format */

import React from "react";

function Signup() {
  return <div>You can signup here</div>;
}

export default Signup;
