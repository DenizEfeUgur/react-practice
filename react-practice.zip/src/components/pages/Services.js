/** @format */

import React from "react";

function Services() {
  return <div>This is the Services site</div>;
}

export default Services;
